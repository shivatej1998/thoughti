package com.example.thoughti.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.thoughti.Entity.Order;
import com.example.thoughti.Repository.OrderRepository;

@RestController
public class OrderController {

	@Autowired
	private OrderSerive orderService;

	@GetMapping("/Orders")
	public List<Order> getProducts() {
		return orderService.getProducts();
	}

	@PostMapping("/create")
	public Order create(@RequestBody Order order) {
		return orderService.create(order);
	}

	@GetMapping("orders/{id}")
	public Order singleProduct(@PathVariable("id") Long id) {
		return orderService.singleProduct(id);
	}

}
