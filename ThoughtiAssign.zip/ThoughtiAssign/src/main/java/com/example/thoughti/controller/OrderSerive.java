package com.example.thoughti.controller;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.thoughti.Entity.Order;
import com.example.thoughti.Repository.OrderRepository;

@Service
public class OrderSerive {

	@Autowired
	private OrderRepository repo;
	
	@Transactional
	public List<Order> getProducts() {
		return repo.findAll();
	}
	
	@Transactional
	public Order create(@RequestBody Order order) {
		return repo.save(order);
	}
	
	@Transactional
	public Order singleProduct(@PathVariable("id") Long id) {
		Optional<Order> findById = repo.findById(id);
		return findById.get();
	}

}
